<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Spreadsheet\\Providers\\SpreadsheetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Spreadsheet\\Providers\\SpreadsheetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);