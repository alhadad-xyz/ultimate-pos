<div class="row">
    <div class="col-md-8 col-xs-12 col-md-offset-2">
        <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-search"></i></span>
            <select id="search_settings" class="form-control" style="width: 100%;">
            </select>
        </div>
        
    </div>
</div>